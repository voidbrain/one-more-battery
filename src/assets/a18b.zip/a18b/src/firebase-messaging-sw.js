
importScripts('https://www.gstatic.com/firebasejs/10.1.0/firebase-app-compat.js')
importScripts('https://www.gstatic.com/firebasejs/10.1.0/firebase-messaging-compat.js')

firebase.initializeApp({


  measurementId: "YOUR_MEASUREMENT_ID",
  apiKey: "AIzaSyBmy0V78f60G3llqJBoRwWUzkOVi_RU3A4",
    authDomain: "more-aa0d7.firebaseapp.com",
    projectId: "more-aa0d7",
    storageBucket: "more-aa0d7.appspot.com",
    messagingSenderId: "215300078730",
    appId: "1:215300078730:web:bad667c140aa57c2dc8173",
    vapidKey: "eX1DRaEu3-7N5SWs38cXBnlJQ-94UDXuwn9ByA2E0r4"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('Received background message ', payload);

  // Customize notification here
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/firebase-logo.png'
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
