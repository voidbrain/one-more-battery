// notification.service.ts
import { Injectable } from '@angular/core';
import { Messaging, getToken, onMessage } from '@angular/fire/messaging';
import { inject } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {

  private serverKey = environment.firebase.apiKey;

  private messaging = inject(Messaging);

  constructor(
    private http: HttpClient
  ) {

    this.listenForMessages();
  }

  // Request permission to send notifications
  public requestPermission() {
    Notification.requestPermission().then((permission) => {
      if (permission === 'granted') {
        console.log('Notification permission granted.');
        this.getToken();
      } else {
        console.error('Notification permission denied.');
      }
    });
  }

  // Get FCM token
  private getToken() {
    getToken(this.messaging, {
      vapidKey: 'YOUR_VAPID_KEY' // Add your VAPID key here
    }).then((currentToken) => {
      if (currentToken) {
        console.log('FCM Token:', currentToken);
        // Optionally send this token to your server to save it
      } else {
        console.error('No FCM token available.');
      }
    }).catch((error) => {
      console.error('An error occurred while retrieving token.', error);
    });
  }

  // Listen for incoming messages
  private listenForMessages() {
    onMessage(this.messaging, (payload) => {
      console.log('Message received. ', payload);
      // Customize your notification here
    });
  }

  sendNotification(token: string, title: string, body: string) {
    const message = {
      to: token,
      notification: {
        title: title,
        body: body,
      },
    };

    this.http.post('https://fcm.googleapis.com/fcm/send', message, {
      headers: {
        'Authorization': `key=${this.serverKey}`,
        'Content-Type': 'application/json',
      }
    }).subscribe(response => {
      console.log('Notification sent successfully:', response);
    }, error => {
      console.error('Error sending notification:', error);
    });
  }
}
