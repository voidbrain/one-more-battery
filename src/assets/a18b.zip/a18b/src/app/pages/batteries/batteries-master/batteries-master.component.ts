import { Component, OnInit } from '@angular/core';
import { getMessaging, getToken } from 'firebase/messaging';
import { initializeApp } from 'firebase/app';
import { onAuthStateChanged } from 'firebase/auth';
import { inject } from '@angular/core';
import { Auth } from '@angular/fire/auth';
import { AuthService } from '../../../services/auth.service';
import { addIcons } from 'ionicons';
import * as ionIcons from 'ionicons/icons';
import { NotificationService } from '../../../services/notifications.service';
import { environment } from '../../../../environments/environment';
import { ModalController } from '@ionic/angular/standalone';
import { ModalExampleComponent } from './modal-example.component';

import { IonButton } from "@ionic/angular/standalone";

@Component({
  selector: 'app-batteries-master',
  templateUrl: './batteries-master.component.html',
  styleUrls: ['./batteries-master.component.scss'],
  standalone: true,
  imports: [IonButton]
})
export class BatteriesMasterComponent  implements OnInit {

  constructor(
    private authService: AuthService,
    private notificationService: NotificationService,
    private modalCtrl: ModalController
  ) {
    addIcons(ionIcons);
  }
  private auth = inject(Auth);
  message = 'This modal example uses the modalController to present and dismiss modals.';

  async openModal() {
    const modal = await this.modalCtrl.create({
      component: ModalExampleComponent,
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();

    if (role === 'confirm') {
      this.requestPermission();
      this.message = `Hello, ${data}!`;
    }
  }

  async ngOnInit() {
    onAuthStateChanged(this.auth, (user) => {
      if (user) {
        console.log('User is signed in:', user);
        // this.requestPermission();

      } else {
        console.log('No user is signed in.');
      }
    });

    const email = 'daniele.bordignon@gmail.com';
    const pwd = '123456';
    // this.authService.signUp(email, pwd)
    const signin = await this.authService.signIn(email, pwd);
  }

  async requestPermission() {
    const firebaseApp = initializeApp(environment.firebase);
    const messaging = getMessaging(firebaseApp);
    const token = await getToken(messaging, { vapidKey: environment.firebase.vapidKey });
    if (token) {
      console.log('FCM Token:', token);
      // Send token to your server to handle notifications
    } else {
      console.log('No registration token available.');
    }
  }

  sendNotification(accessToken: string) {
    const token = accessToken; // Replace with actual user FCM token
    const title = 'Test Notification';
    const body = 'This is a test notification from Angular!';
    this.notificationService.sendNotification(token, title, body);
  }

}
