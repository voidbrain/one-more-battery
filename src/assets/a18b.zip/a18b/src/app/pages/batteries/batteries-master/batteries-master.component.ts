import { Component, OnInit } from '@angular/core';

import { onAuthStateChanged } from 'firebase/auth';
import { inject } from '@angular/core';
import { Auth } from '@angular/fire/auth';
// import { AuthService } from '../../../services/auth.service';
import { addIcons } from 'ionicons';
import * as ionIcons from 'ionicons/icons';
import { NotificationService } from '../../../services/notifications.service';

@Component({
  selector: 'app-batteries-master',
  templateUrl: './batteries-master.component.html',
  styleUrls: ['./batteries-master.component.scss'],
})
export class BatteriesMasterComponent  implements OnInit {

  constructor(
    // private authService: AuthService,
    private notificationService: NotificationService
  ) {
    addIcons(ionIcons);
  }
  private auth = inject(Auth);


  ngOnInit() {
    onAuthStateChanged(this.auth, (user) => {
      if (user) {
        console.log('User is signed in:', user);
      } else {
        console.log('No user is signed in.');
      }
    });

    // const email = 'daniele.bordignon@gmail.com';
    // const pwd = '123456';
    // this.authService.signUp(email, pwd)
    this.sendNotification();
  }

  sendNotification() {
    const token = 'USER_FCM_TOKEN'; // Replace with actual user FCM token
    const title = 'Test Notification';
    const body = 'This is a test notification from Angular!';
    this.notificationService.sendNotification(token, title, body);
  }

}
