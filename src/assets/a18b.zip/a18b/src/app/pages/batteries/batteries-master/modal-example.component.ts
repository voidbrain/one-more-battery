import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ModalController } from '@ionic/angular/standalone';
import { IonToolbar, IonButtons, IonButton, IonTitle, IonContent, IonItem, IonInput, IonHeader } from "@ionic/angular/standalone";

@Component({
  selector: 'app-modal-example',
  templateUrl: './modal-example.component.html',
  standalone: true,
  imports: [IonHeader, IonInput, IonItem, IonContent, IonTitle, IonButton, IonButtons, IonToolbar,
  FormsModule, ReactiveFormsModule]
})
export class ModalExampleComponent {
  name: string = '';

  constructor(private modalCtrl: ModalController) {}

  cancel() {
    return this.modalCtrl.dismiss(null, 'cancel');
  }

  confirm() {
    return this.modalCtrl.dismiss(this.name, 'confirm');
  }
}
