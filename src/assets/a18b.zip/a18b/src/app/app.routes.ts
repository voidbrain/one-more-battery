import { Routes } from '@angular/router';
import { TabsComponent } from './pages/tabs/tabs.component';
import { BatteriesMasterComponent } from './pages/batteries/batteries-master/batteries-master.component';

export const routes: Routes = [
  {
    path: 'tabs',
    component: TabsComponent,
    children: [
      { path: 'batteries', component: BatteriesMasterComponent },
      {
        path: '',
        redirectTo: 'batteries',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    redirectTo: 'tabs',
    pathMatch: 'full',
  },
  { path: '**', redirectTo: 'tabs' } // Handle undefined paths
];
