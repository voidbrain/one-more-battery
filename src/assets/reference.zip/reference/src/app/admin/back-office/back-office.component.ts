import { Component } from '@angular/core';

@Component({
  selector: 'app-back-office',
  standalone: true,
  imports: [],
  templateUrl: './back-office.component.html',
  styleUrl: './back-office.component.scss'
})
export class BackOfficeComponent {

}
