import { Component } from '@angular/core';

@Component({
  selector: 'app-appointment-picker',
  standalone: true,
  imports: [],
  templateUrl: './appointment-picker.component.html',
  styleUrl: './appointment-picker.component.scss'
})
export class AppointmentPickerComponent {

}
